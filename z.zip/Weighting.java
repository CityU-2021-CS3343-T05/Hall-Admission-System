package HallAdmissionSystem;

public interface Weighting {

	void setWeightValue(int v);

	int getValue();

}