package HallAdmissionSystem;

public interface Score {

	void setScoreValue(String v);

	int getValue();

}