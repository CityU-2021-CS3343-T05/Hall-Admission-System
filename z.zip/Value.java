package HallAdmissionSystem;

public interface Value {

	int getValue();

	void setValue(int v);

}